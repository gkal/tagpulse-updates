import{j as o}from"./react-vendor-D4jCDvs5.js";function i(r,n="text-white"){return r?r.split(/\*\*(.+?)\*\*/g).map((t,s)=>s%2===1?o.jsx("strong",{className:n,children:t},s):t):[]}export{i as b};
